const express = require("express")
const app = express()
const port = 3000
app.use(express.json()) // configura API para usar JSON.
const fs = require('fs') // importa leitura e escrita de arquivos.

let arquivoID = JSON.parse(fs.readFileSync("id.json", "utf8"))
let id = arquivoID.id 

function atualizarId(){
    id = id + 1
    fs.writeFileSync("id.json", JSON.stringify({id: id}), "utf8")
}

/*    Mostra a lista de aulas       */
app.get("/aulas", (req,res) => {
    try {
        /*     Abrir o arquivo         */
        const bd = JSON.parse(fs.readFileSync("aulas.json", "utf8"))
        res.status(200).json({resposta: bd})
    } catch (erro) {
        res.status(500).json({ erro: erro.message })
    }
})

/*    Adiciona aula                 */
app.post("/aulas", (req,res) => {
    const aula = req.body
    try {
        /*     Abrir o arquivo         */
        const bd = JSON.parse(fs.readFileSync("aulas.json", "utf8"))
        atualizarId()
        aula.id = id
        /*     adicionar aula     */
        bd.push(aula)
        /*     salvar o arquivo        */
        fs.writeFileSync("aulas.json", JSON.stringify(bd), "utf8")
        /*     Resposta                */
        res.status(201).json({ resposta: "Aula cadastrada com sucesso!" })
    } catch (erro) {
        res.status(500).json({ erro: erro.message })
    }
})


/*    Deleta uma aula da lista      */
app.delete("/aulas/:id", (req,res) => {

    /*     Pegar uma aula da rota            */
    const id = req.params.id
try{
    /*     Abrir o arquivo               */
    const bd = JSON.parse(fs.readFileSync("aulas.json", "utf8"))
    /*     Encontra o indece da aula a ser excluida */
    const indiceAula = bd.findIndex((aula) => aula.id == id)
    /*     Remove o indice da lista      */
    if(indiceAula == -1){
        return res.status(404).json({erro: "Aula não encontrada"})
    }
    bd.splice(indiceAula, 1)
    /*     Atualizar o arquivo           */
    fs.writeFileSync("aulas.json", JSON.stringify(bd), "utf8")
    /*     Dar uma resposta   */
        res.status(200).json({resposta: "Aula removida com sucesso!"})
    }catch(erro){
        res.status(500).json({ erro: erro.message })
    }
})

// Execução da API:
app.listen(port, ()=>{
    console.log("API rodando na porta " + port)
})






/*               GET     -     ​http://localhost:3000/aulas                              */
/*               POST    -     ​http://localhost:3000/aulas                              */
/*               DELETE  -     ​http://localhost:3000/aulas                              */

/*               Instalar extennção RapidAPI Client                                     */
/*               Instalar      npm init    e    npm i express                           */